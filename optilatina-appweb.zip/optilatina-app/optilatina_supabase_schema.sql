-- ══════════════════════════════════════════════════════════════
-- OPTILATINA — Supabase Schema
-- Corre este SQL completo en el SQL Editor de tu proyecto Supabase
-- ══════════════════════════════════════════════════════════════

-- Enable UUID extension (por si acaso)
create extension if not exists "pgcrypto";

-- ── 1. INVENTORY ─────────────────────────────────────────────
create table if not exists inventory (
  id           text primary key,
  name         text not null,
  cat          text default 'Otro',
  cost         numeric(12,2) default 0,
  price        numeric(12,2) default 0,
  is_service   boolean default false,
  serials      jsonb default '[]',
  photo        text,            -- base64 o URL
  description  text default '',
  store_id     text,
  created_at   timestamptz default now(),
  updated_at   timestamptz default now()
);
create index if not exists idx_inv_cat      on inventory(cat);
create index if not exists idx_inv_store    on inventory(store_id);
create index if not exists idx_inv_service  on inventory(is_service);

-- ── 2. SALES ─────────────────────────────────────────────────
create table if not exists sales (
  id              text primary key,
  sale_id         text,
  date            text not null,         -- YYYY-MM-DD
  note            text default '',
  payment_method  text default 'cash',
  registered_by   text,
  store_id        text,
  product_id      text,
  product_name    text,
  cat             text,
  cost            numeric(12,2) default 0,
  price           numeric(12,2) default 0,
  qty             integer default 1,
  total           numeric(12,2) default 0,
  profit          numeric(12,2) default 0,
  total_bs        numeric(14,2),         -- Bs para pago móvil
  serials         jsonb default '[]',
  frame_type      text,
  crystal_type    text,
  lab             text,
  lab_cost        numeric(12,2) default 0,
  rx              jsonb,                 -- fórmula óptica
  created_at      timestamptz default now()
);
create index if not exists idx_sales_date    on sales(date);
create index if not exists idx_sales_store   on sales(store_id);
create index if not exists idx_sales_sale_id on sales(sale_id);
create index if not exists idx_sales_month   on sales(substring(date,1,7));

-- ── 3. EXPENSES (gastos fijos) ───────────────────────────────
create table if not exists expenses (
  id          text primary key,
  cat         text not null,
  amount      numeric(12,2) default 0,
  month       text,              -- YYYY-MM
  date        text,              -- YYYY-MM-DD
  note        text default '',
  created_at  timestamptz default now()
);
create index if not exists idx_exp_month on expenses(month);
create index if not exists idx_exp_cat   on expenses(cat);

-- ── 4. DEPOSITS (depósitos de caja) ─────────────────────────
create table if not exists deposits (
  id          text primary key,
  date        text not null,
  amount      numeric(12,2) default 0,
  note        text default '',
  created_at  timestamptz default now()
);
create index if not exists idx_dep_date on deposits(date);

-- ── 5. INVESTMENTS (inversiones) ────────────────────────────
create table if not exists investments (
  id          text primary key,
  date        text not null,
  amount      numeric(12,2) default 0,
  description text default '',
  note        text default '',
  created_at  timestamptz default now()
);
create index if not exists idx_inv2_date on investments(date);

-- ── 6. SETTINGS (clave-valor: tasa, perfiles, pagos…) ───────
create table if not exists settings (
  key         text primary key,
  value       jsonb not null,
  updated_at  timestamptz default now()
);

-- ══════════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY (RLS)
-- Habilitamos RLS pero permitimos todo con anon key para esta app
-- (la seguridad viene del PIN, no del row-level)
-- ══════════════════════════════════════════════════════════════

alter table inventory   enable row level security;
alter table sales        enable row level security;
alter table expenses     enable row level security;
alter table deposits     enable row level security;
alter table investments  enable row level security;
alter table settings     enable row level security;

-- Políticas: acceso total con anon key (la app maneja auth por PIN)
create policy "anon_all_inventory"   on inventory   for all to anon using (true) with check (true);
create policy "anon_all_sales"        on sales        for all to anon using (true) with check (true);
create policy "anon_all_expenses"     on expenses     for all to anon using (true) with check (true);
create policy "anon_all_deposits"     on deposits     for all to anon using (true) with check (true);
create policy "anon_all_investments"  on investments  for all to anon using (true) with check (true);
create policy "anon_all_settings"     on settings     for all to anon using (true) with check (true);

-- ══════════════════════════════════════════════════════════════
-- FUNCIÓN: auto-update updated_at en inventory
-- ══════════════════════════════════════════════════════════════
create or replace function update_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger trg_inventory_updated
  before update on inventory
  for each row execute function update_updated_at();

create trigger trg_settings_updated
  before update on settings
  for each row execute function update_updated_at();

-- ══════════════════════════════════════════════════════════════
-- REALTIME: habilitar publicación para sincronización en tiempo real
-- ══════════════════════════════════════════════════════════════
alter publication supabase_realtime add table inventory;
alter publication supabase_realtime add table sales;
alter publication supabase_realtime add table settings;
alter publication supabase_realtime add table expenses;
alter publication supabase_realtime add table deposits;
alter publication supabase_realtime add table investments;
