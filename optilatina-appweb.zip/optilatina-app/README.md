# Optilatina — Instrucciones de despliegue

## ✅ Antes de publicar

1. **Configura Supabase** en `public/App.jsx` (líneas 9-10):
   ```js
   const SUPA_URL = "https://TU_PROYECTO.supabase.co";
   const SUPA_KEY = "TU_ANON_KEY";
   ```

2. Corre el schema SQL en Supabase SQL Editor
   (archivo: `optilatina_supabase_schema.sql`)

---

## 🚀 Desplegar en Vercel (gratis, 5 minutos)

### Opción A — Arrastra y suelta (más fácil)
1. Ve a https://vercel.com → Sign up con Google/GitHub
2. Clic en **Add New → Project**
3. Elige **"Deploy from template"** → o arrastra la carpeta `optilatina-app`
4. Vercel detecta el `vercel.json` y despliega solo
5. Obtienes una URL como `https://optilatina.vercel.app`

### Opción B — GitHub (recomendado para actualizaciones fáciles)
```bash
# 1. Instala Git si no lo tienes
# 2. En la carpeta optilatina-app:
git init
git add .
git commit -m "Optilatina v1.0"
# 3. Sube a GitHub (github.com → New repository)
git remote add origin https://github.com/TU_USUARIO/optilatina.git
git push -u origin main
# 4. En Vercel: Import Git Repository → selecciona optilatina
```
Con GitHub, cada vez que hagas cambios y los subas, Vercel actualiza la app automáticamente.

---

## 📱 Instalar como app en el celular

### Android (Chrome)
1. Abre la URL en Chrome
2. Menú (3 puntos) → **"Agregar a pantalla de inicio"**
3. La app aparece como ícono nativo

### iPhone (Safari)
1. Abre la URL en Safari (NO Chrome en iOS)
2. Ícono de compartir → **"Agregar a pantalla de inicio"**
3. La app aparece como ícono nativo

---

## 🔄 Estructura de archivos

```
optilatina-app/
├── vercel.json          ← Configuración de despliegue
└── public/
    ├── index.html       ← Entrada principal (PWA)
    ├── App.jsx          ← Toda la lógica de la app
    ├── manifest.json    ← Config PWA (nombre, ícono, colores)
    ├── sw.js            ← Service Worker (modo offline)
    ├── icon-192.png     ← Ícono app (192×192)
    └── icon-512.png     ← Ícono app (512×512)
```

---

## 🛠 Hacer actualizaciones

1. Edita `public/App.jsx` con los cambios que quieras
2. Si usas GitHub: `git add . && git commit -m "mejora" && git push`
3. Vercel despliega automáticamente en segundos
